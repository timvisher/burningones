=== WP-DBManager ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: database, manage, wp-dbmanager, manager, table, optimize, backup, queries, query, drop, empty, tables, table, run, repair, cron, schedule, scheduling, automatic
Requires at least: 2.5.0
Stable tag: 2.31

Manages your WordPress database.

== Description ==

Allows you to optimize database, repair database, backup database, restore database, delete backup database , drop/empty tables and run selected queries. Supports automatic scheduling of backing up and optimizing of database.

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-DBManager Readme](http://lesterchan.net/wordpress/readme/wp-dbmanager.html "WP-DBManager Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-DBManager Readme](http://lesterchan.net/wordpress/readme/wp-dbmanager.html "WP-DBManager Readme") (Installation Tab)

== Screenshots ==

[WP-DBManager Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-dbmanager/ "WP-DBManager Screenshots")

== Frequently Asked Questions ==

[WP-DBManager Support Forums](http://forums.lesterchan.net/index.php?board=11.0 "WP-DBManager Support Forums")