=== Akismet ===
Contributors: matt, ryan, andy, mdawaffe
Tags: akismet, comments, spam

Akismet checks your comments against the Akismet web service to see if they look like spam or not.

== Description ==

Akismet checks your comments against the Akismet web service to see if they look like spam or not and lets you
review the spam it catches under your blog's "Comments" admin screen.

Want to show off how much spam Akismet has caught for you? Just put `<?php akismet_counter(); ?>` in your template.

See also: [WP Stats plugin](http://wordpress.org/extend/plugins/stats/).

PS: You'll need a [WordPress.com API key](http://wordpress.com/api-keys/) to use it.

== Installation ==

Upload the Akismet plugin to your blog, Activate it, then enter your [WordPress.com API key](http://wordpress.com/api-keys/).

1, 2, 3: You're done!
